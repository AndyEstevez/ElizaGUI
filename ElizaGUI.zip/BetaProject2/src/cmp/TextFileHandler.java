package cmp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFileChooser;

public class TextFileHandler implements TextFileIOable {
	
	@Override
	public void createNewFile(String fileName) { // creates new empty file
		PrintWriter outStream = null;
			try {
				outStream = new PrintWriter(fileName);
				
			}catch(FileNotFoundException e) {
				System.out.println("Could not create the file "+fileName);
				e.printStackTrace();
			}
			finally {
				outStream.flush(); // send to destination
				
				if(outStream != null) {
					outStream.close();
				}
			}
				
				
		
	}

	@Override
	public void writeToNewFile(String fileName, String text) {
		PrintWriter outStream = null;
		try {
			outStream = new PrintWriter(fileName);
			outStream.println(text); // write the text to the file
			
		}catch(FileNotFoundException e) {
			System.out.println("Could not create the file "+fileName);
			e.printStackTrace();
		}
		finally {
			
			
			if(outStream != null) {
				outStream.close();
			}
			System.out.println("All done check your file system for "+fileName);
		}
			
			
	
		
		
	}

	@Override
	public void appendToFile(String fileName, String text) {
		PrintWriter outStream = null;
		try {
			//outStream = new PrintWriter(fileName); // replace this line
			outStream = new PrintWriter(new FileOutputStream(fileName, true)); // true means append to end of file
			outStream.println(text); // write the text to the file
			
		}catch(FileNotFoundException e) {
			System.out.println("Could not create the file "+fileName);
			e.printStackTrace();
		}
		finally {
			
			
			if(outStream != null) {
				outStream.close();
			}
			//System.out.println("All done check your file system for "+fileName);
		}
			
			
		
	}

	@Override
	public boolean deleteFile(String fileName) {
		File file = new File(fileName);
		
		if(file.exists()) {
			if(file.delete()) {
				System.out.println("The file "+fileName+" was deleted");

				return true;
			}
		}
		
		else {
			System.out.println("The file "+fileName+" was NOT deleted or doesn't not exist");
			return true;
		}
		
		return false;
		
	}

	@Override
	public String readFile(String fileName) {
		Scanner inStream = null;
		String fileContents = "";
		
		try {
			
			File theFileObject = new File(fileName);
			inStream = new Scanner(theFileObject);
			
			while(inStream.hasNextLine()){ // use the Scanner object's hasNextLine method
			fileContents += inStream.nextLine() + "\n"; // get a line from the file append to file content String
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			if(inStream != null) {
				inStream.close();
			}
		}
		
		
		return fileContents;
	}

	@Override
	public boolean copyFile(String fileNameOrig) {

		
		return false;
	}

	@Override
	public boolean copyFile(String fileNameOrig, String fileNameCopy) {
		Scanner inStream = null;
		PrintWriter outStream = null;
		
		try {
			inStream = new Scanner(new File(fileNameOrig));
			outStream = new PrintWriter(new File(fileNameCopy));
			while(inStream.hasNextLine()) {
				String modString = inStream.nextLine();
				outStream.println(modString);
				//can be used to modify a string from the text file
				
				//char c1 = modString.charAt(0);
				//String lineOut = Character.toUpperCase(c1) + modString.substring(1);
				//outStream.println(lineOut);
			}
			return true;
		}
	
		
		catch(FileNotFoundException e) {
			System.out.println("Problem copying the file");
			e.printStackTrace();
		}
		
		finally {
			if(inStream != null) {
				inStream.close();
			}
			if(outStream != null) {
				outStream.close();
			}
			System.out.println("finished check your file system");
		}
		
		
		
		return false;
	}

	@Override
	public String readDelimetedFile(String fileName, String delimiter) {
		
		Scanner inStream = null;
		String token = "";
		String fileContent = "";
		try {
			File theFile = new File(fileName);
			if((theFile.exists()) && theFile.canRead()){
				inStream = new Scanner(theFile);
				inStream.useDelimiter(delimiter);
				while(inStream.hasNext()) {
					token = inStream.next();
					System.out.println(token);
					fileContent += token+"\n"; 
					String lineln = inStream.nextLine();
					String []tokens = lineln.split(delimiter);
					for(int i = 0; i < tokens.length; i++) {
						fileContent += tokens[i] + "\n";
					}
				}
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			if(inStream !=null) {
				inStream.close();
			}
			System.out.println();
		}
		
		
		
		return null;
	}

	@Override
	public boolean findAndReplaceFileContent(String fileName, String textOrig, String textReplacement) {
		// TODO Auto-generated method stub
		return false;
	}

	public String readFileFromFileChooser() {
		JFileChooser jfc = new JFileChooser();
		int yesNo = jfc.showDialog(null, null);
		
		if(yesNo == JFileChooser.APPROVE_OPTION) {
			File file = jfc.getSelectedFile();
			if(file.isFile()) {
				return readFile(file.getAbsolutePath());
			}
		}
		
		return "";
	}
	
	public void recursivelyShowFilesAndDirNames(String fileName) {
		File fileObj = new File(fileName);
		
		if(fileObj.exists()) { 
			if(fileObj.isFile()) { // base case also for if the object is a file 
			System.out.println("File: " + fileName);
			}
		
		
			else { // recursive case heading to the base case if it not a file 
			System.out.println("Dir: " + fileName);
			File [] files = fileObj.listFiles();
			
			for(int i = 0; i < files.length; i++) {
				recursivelyShowFilesAndDirNames(files[i].getAbsolutePath());
				}
			}
		}
	}
		public void appendToArrayFile(String fileName, ArrayList<String> arr) {
			PrintWriter outStream = null;
			try {
				//outStream = new PrintWriter(fileName); // replace this line
				outStream = new PrintWriter(new FileOutputStream(fileName, true)); // true means append to end of file
				outStream.println(arr); // write the text to the file
			}catch(FileNotFoundException e) {
				System.out.println("Could not create the file "+fileName);
				e.printStackTrace();
			}
			finally {
				
				
				if(outStream != null) {
					outStream.close();
				}
				//System.out.println("All done check your file system for "+fileName);
			}
		}

		
		
		
		
		
	

}

