package cmp;

import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Eliza_Gui extends JFrame implements ActionListener {
	
	public static final int NUM_QUESTIONS = 10; 
	TextFileHandler tfHandler;
	Question_Bank qb;
	private JPanel jpanel, jpanel2, jpanel3;
	private JLabel jlabel, jlabel2;
	private JButton jbtnStartSession, jbtnNextQuestion, jbtnFinishSession, jbtnViewAll, jbtnLongWords, jbtnLongWordsInOrder;
	private JTextField jtextf;
	private JTextArea jtexta;
	private JScrollPane jscroll;
	
	public static ArrayList<String> words = new ArrayList<String>();
	private static int incrementNum = 1;
	private static int numIncrease = 1;
	private static int counter = 0;
	private boolean isLoop = false;
	private static final int GUI_WIDTH = 500;
	private static final int NUMS_COLS_TEXT_AREA = GUI_WIDTH / 15;
	
	
	public Eliza_Gui() {
		
		qb = new Question_Bank();
		tfHandler = new TextFileHandler();
		
		
		jpanel = new JPanel();
		jpanel2 = new JPanel();
		jpanel3 = new JPanel();
		
		jlabel = new JLabel();
		jlabel2 = new JLabel();
		
		jbtnStartSession = new JButton();
		jbtnNextQuestion = new JButton();
		jbtnFinishSession = new JButton();
		jbtnViewAll = new JButton();
		jbtnLongWords = new JButton();
		jbtnLongWordsInOrder = new JButton();
		
		jtextf = new JTextField(NUMS_COLS_TEXT_AREA);
		jtexta = new JTextArea(24,100);
		jscroll = new JScrollPane(jtexta, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS); 
		
		
		jlabel.setText("Welcome to the Eliza therapy session, Start Session to begin");
		jbtnStartSession.setText("Start Session");
		jbtnNextQuestion.setText("Next Question");
		jbtnFinishSession.setText("Finish Session");
		jbtnViewAll.setText("View all Q & A");
		jbtnLongWords.setText("View Longest Words");
		jbtnLongWordsInOrder.setText("View Longest Words Alphabetically");
		
		setTitle("Eliza GUI");  
		jbtnStartSession.addActionListener(this);
		jbtnNextQuestion.addActionListener(this);
		jbtnFinishSession.addActionListener(this);
		
		// hides certain buttons and text field at the beginning
		jbtnViewAll.setVisible(false);
		jbtnLongWords.setVisible(false);
		jbtnLongWordsInOrder.setVisible(false);
		jbtnNextQuestion.setVisible(false);
		jbtnFinishSession.setVisible(false);
		jtextf.setVisible(false);
		
		jtexta.setBackground(Color.DARK_GRAY);
		jtexta.setVisible(true);
		jtexta.setEnabled(false);
		
		jscroll.setVisible(false);
		jscroll.setEnabled(true);
		
		// add parts to the first java panel
		jpanel.add(jlabel, BorderLayout.NORTH);
		jpanel.add(jlabel2, BorderLayout.CENTER);
		jpanel.add(jbtnStartSession);
		jpanel.add(jtextf);
		jpanel.add(jbtnNextQuestion);
		jpanel.add(jbtnFinishSession);
		// add parts to the second java panel
		jpanel2.add(jbtnViewAll);
		jpanel2.add(jbtnLongWords);
		jpanel2.add(jbtnLongWordsInOrder);
		jpanel2.add(jscroll); //  you don't add the j text area instead you add the j scroll since it has it directed to it
		
		jpanel3.add(jpanel); // add JPanel 1 to the bigger panel
		jpanel3.add(jpanel2); //  add JPanel 2 to the bigger panel
		this.add(jpanel3);
		
		this.setSize(1000,1000);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String btnClicked =  e.getActionCommand();
		String myfile = "myFiles/insert.txt";
		
		String sessionQuestion = jlabel.getText(); 
		String userInput = jtextf.getText();
		String longWord = getLongestWord(userInput);
		// the loop begins
		do {
			
			switch(btnClicked) {
			
			case "Start Session": 
				
				tfHandler.createNewFile(myfile); // creates the text file
				
				jbtnStartSession.setVisible(false); // hides the start session button since the session has started
				jbtnNextQuestion.setVisible(true); // shows the next question button since the session has started
				jtextf.setVisible(true); // shows where the user can type now
				
				//jbtnNextQuestion.setText("Next Question");
				jlabel.setText("Session # "+numIncrease+" Question "+incrementNum+": "+qb.getNextQuestion());
				
				tfHandler.appendToFile(myfile, sessionQuestion);
				tfHandler.appendToFile(myfile, userInput);
				
				longWord = getLongestWord(userInput);
				words.add(longWord);
				
				incrementNum++;
				
				isLoop = false;
				break;
			
			case "Next Question":
				
				if(counter < 9) {
					jlabel.setText("Session # "+ numIncrease+" Question "+incrementNum+": "+qb.getNextQuestion());
					tfHandler.appendToFile(myfile, sessionQuestion);
					tfHandler.appendToFile(myfile, userInput);
					longWord = getLongestWord(userInput);
					words.add(longWord); // adds the longest word to the Array List
					
					System.out.println(getLongestWord(userInput));
				}
				counter++;
				incrementNum++;
				if(counter == 9) {
					
				
					jlabel.setText("Session # "+ numIncrease+" Question 10: "+qb.getNextQuestion());
					
					jbtnFinishSession.setVisible(true);
					jbtnNextQuestion.setVisible(false);
					jbtnLongWords.addActionListener(this);
				}
				
				isLoop = false;
				break;
				
			case "View all Q & A":
				
				displayFile(); // show the file in the java text area
				jtexta.setEnabled(false);
				jtexta.setVisible(true);
				jbtnViewAll.setEnabled(false);
				
				break;
			case "View Longest Words":
				displayFile();
				tfHandler.appendToArrayFile(myfile, words);
				break;
			case "View Longest Words Alphabetically":
				break;
			case "Finish Session": 
				
				//jlabel.setText("Session # "+ numIncrease+" Question "+incrementNum+": "+qb.getNextQuestion());
				//tfHandler.appendToFile(myfile, sessionQuestion);
				//tfHandler.appendToFile(myfile, userInput);
				
				longWord = getLongestWord(userInput);
				words.add(longWord);
				tfHandler.appendToFile(myfile, sessionQuestion);
				tfHandler.appendToFile(myfile, userInput);
				
				jbtnStartSession.setVisible(true);
				jbtnNextQuestion.setVisible(false);
				jbtnViewAll.setVisible(true);
				jbtnLongWords.setVisible(true);
				jbtnLongWordsInOrder.setVisible(true);
				jbtnViewAll.setEnabled(true);
				jbtnViewAll.addActionListener(this);
				jbtnLongWords.addActionListener(this);
				
				jlabel.setText("Press Start Session to begin");
				jbtnFinishSession.setVisible(false);
				jscroll.setEnabled(true);
				jscroll.setVisible(true);
				
				numIncrease++;
				counter = 0;
				incrementNum = 1;
			/*	
			default:
				jbtnStartSession.setVisible(true);
				jlabel.setText("Press Start Session to begin");
				jbtnFinishSession.setVisible(false);
				jbtnViewAll.setVisible(true);
				jbtnLongWords.setVisible(true);
				jbtnLongWordsInOrder.setVisible(true);
				continue;
				*/
			}
		}while (isLoop == true);
	
	}
	
	
	public void appendToFile(String fileName, String text) { // write to the file 
		PrintWriter outStream = null;
		try {
			//outStream = new PrintWriter(fileName); // replace this line
			outStream = new PrintWriter(new FileOutputStream(fileName, true)); // true means append to end of file
			outStream.println(text); // write the text to the file
		}catch(FileNotFoundException e) {
			System.out.println("Could not create the file "+fileName);
			e.printStackTrace();
		}
		finally {
			
			
			if(outStream != null) {
				outStream.close();
			}
			//System.out.println("All done check your file system for "+fileName);
		}
		
	}
	
	public void displayFile() {
		TextFileHandler tfHandler = new TextFileHandler();
		String fileName = "myFiles/insert.txt";
		
		String fileContent = tfHandler.readFile(fileName);
		jtexta.append(fileContent);
	}
	
	public static String compareStrings(String string1, String string2) {
	    if (string1.length() < string2.length()) {
		      return string2;
		    } 
		    else {
		      return string1;
		    }
		}
	
	public static String getLongestWord(String s) {
			String arr[] = s.split(" ");
			
			String word = "";
			for(int i = 0; i < arr.length; i++) {
				if(i == 0) {
					word = arr[0];
				}
				word = compareStrings(word, arr[i]);
			}
			return word;
		}

	}
	
