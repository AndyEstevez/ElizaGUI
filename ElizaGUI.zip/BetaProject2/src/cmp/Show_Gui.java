package cmp;

public class Show_Gui {
	public static void main(String[] args) {

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Eliza_Gui gui = new Eliza_Gui();
			}
		});
	}
}
